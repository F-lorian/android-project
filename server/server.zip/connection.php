        <div id="global-container" class="container-fluid">
            <h4>Sign Project</h4>
            <div class="panel">
                <div class="panel-header">
                    <span class="label label-default">Connexion</span>
                </div>
                <div class="panel-body">
                    <form action="" method="post" onsubmit="">
                        <input type="text" class="form-control" id="login" placeholder="login" onblur="" name="login" value="" required>
                        <input type="password" class="form-control" id="password" placeholder="mot de passe" name="password" required>
                        <button id="btn_connexion" type="submit" class="btn btn-primary btn-block" onclick="">connexion</button>
                    </form>
                </div>
            </div>
        </div>
    </body>

</html>