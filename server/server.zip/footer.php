<?php
if(isset($isLogged) && $isLogged){
?>
    <script src="js/jquery-2.1.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootbox.min.js"></script>
        <script src="js/list_plugin.js"></script>
        <script src="js/tab_plugin.js"></script>
        <script src="js/scripts.js"></script>
    </body>

</html>
<?php
}
?>
