<?php

// Database config variables
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "sign_project");
 
// Google Cloud Messaging API Key
// Place your Google API Key
define("API_ACCESS_KEY", "YOUR-API-ACCESS-KEY-GOES-HERE"); 
                           
?>